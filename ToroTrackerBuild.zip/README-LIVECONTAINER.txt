TORO DUMPSTERS TRACKER — LIVECONTAINER TEST BUILD

This package contains a native iPhone wrapper around the Toro Dumpster Tracker.

HOW TO MAKE THE IPA ON YOUR MAC
1. Unzip this package.
2. Double-click BUILD-IPA.command.
   - If macOS blocks it, right-click it -> Open.
   - Or open Terminal, drag BUILD-IPA.command into Terminal, then press Return.
3. When the build finishes, an output folder opens.
4. Send ToroTracker-LiveContainer.ipa to your iPhone (AirDrop, iCloud Drive, etc.).

HOW TO OPEN IT IN LIVECONTAINER
1. Open LiveContainer.
2. Tap the + button.
3. Choose ToroTracker-LiveContainer.ipa from Files.
4. Let LiveContainer import/sign it, then launch Toro Tracker.

NOTES
- No server is required; the tracker interface is bundled inside the IPA.
- Inventory and rental data are saved locally by the app's WKWebView.
- If LiveContainer is reset/reinstalled or the app's data container is deleted, local data can be lost.
- Use the app's backup/export feature when you start entering real business data.

The project targets iOS 15+ so it can run on newer iOS versions as well.

GOOGLE MAPS
- Jobsite navigation buttons now use Google Maps.
- If the Google Maps iPhone app is installed, the address opens there.
- Otherwise, it opens the same address in Google Maps on the web.
- Apple Maps is not used for jobsite navigation.
